#include<iostream>
using namespace std;
const int size=3;
int main(){
	int var[size]={5,10,15};
	int *ptr;
	ptr=var;
	for(int i=0;i<size;i++){
		cout<<"Address of var["<<i<<"]=";
		cout<<ptr<<endl;
		cout<<"Value of var["<<i<<"]=";
		cout<<*ptr<<endl;
		ptr++;
	}
	return 0;
}

#include<iostream>
using namespace std;
void temp(int *x,int *y){
	*x=*x+100;
	*y=*y+100;
}
int main(){
	void temp(int*,int*);
	int a,b;
	a=10;
	b=20;
	temp (&a,&b);
	cout<<"Value of a = "<<a<<endl;
	cout<<"Value of b = "<<b<<endl;
	cout<<"Okay"<<endl;
	system("PAUSE");
	return 0;
}

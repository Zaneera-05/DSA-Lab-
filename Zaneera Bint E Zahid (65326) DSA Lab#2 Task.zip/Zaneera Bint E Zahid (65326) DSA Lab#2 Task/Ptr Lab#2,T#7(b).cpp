#include<iostream>
using namespace std;
void passByReference(int &x){
    x=10;
}
int main(){
    int a=5;
    passByReference(a);
    cout<<"After passByReference, a="<<a<<endl;
    return 0;
}

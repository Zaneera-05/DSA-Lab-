#include<iostream>
using namespace std;

void passByValue(int x) {
    x = 10;
}
int main() {
    int a = 5;
    passByValue(a);
    cout << "After passByValue, a = " << a << endl;
    return 0;
}

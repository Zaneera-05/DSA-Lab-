#include<iostream>
using namespace std;
int main(){
	int a=58;
	int *ptr=&a;
	int **p=&ptr;
	cout<<a<<endl;
	cout<<*ptr<<endl;
	cout<<**p<<endl;
	return 0;
}

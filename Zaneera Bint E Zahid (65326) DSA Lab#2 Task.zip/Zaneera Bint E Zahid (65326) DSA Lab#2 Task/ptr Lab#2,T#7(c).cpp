#include<iostream>
using namespace std;
void passByPointer(int *x){
    *x=10;
}
int main(){
    int a=5;
    passByPointer(&a);
    cout<<"After passByPointer, a="<<a<<endl;
    return 0;
}


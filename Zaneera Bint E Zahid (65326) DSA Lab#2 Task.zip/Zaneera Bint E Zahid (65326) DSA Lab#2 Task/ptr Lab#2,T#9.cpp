#include<iostream>
using namespace std;
void PrintString(char *sss){
	while(*sss!=0)
	{
		cout<<*sss<<endl;
		*sss++;
	}
}
int main(){
	char st[]="Pakistan";
	void PrintString(char *)
}

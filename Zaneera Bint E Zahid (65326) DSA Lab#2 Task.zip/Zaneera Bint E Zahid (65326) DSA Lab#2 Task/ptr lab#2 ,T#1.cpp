#include<iostream>
using namespace std;
int main(){
	int a,b;
	a=98;
	b=100;
	cout<<"The address of a is: "<<&a<<endl;
	cout<<"The address of b is :"<<&b<<endl;
	return 0;
}

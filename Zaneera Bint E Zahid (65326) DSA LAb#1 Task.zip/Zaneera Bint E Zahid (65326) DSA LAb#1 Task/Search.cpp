#include<iostream>
using namespace std;

int main(){
	int size=5;
	int Array[10]={10,20,30,40,50};
	cout<<"Array:"<<endl;
	for(int i=0;i<size;i++){
		cout<<Array[i]<<" ";
	}
	cout<<endl;
	int choice;
	cout<<"\nSearch Menu:\n";
	cout<<"1.Search by index\n";
	cout<<"2.Search by value\n";
	cout<<"Enter your choice:";
	cin>>choice;
	if(choice==1){
		int index;
		cout<<"Enter index (0-4):";
		cin>>index;
		if(index >=0 && index<size){
            cout<<"Element at index: "<<index<<" is "<<Array[index]<<endl;
        }
		else{
            cout<<"Invalid index!"<<endl;
        }
    }
	else if(choice==2){
        int value, found=0;
        cout<<"Enter value to search: ";
        cin>>value;
        cout<<"Value "<<value<<" found at index ";
        for(int i=0; i<size;i++){
            if(Array[i] == value){
                cout<<i<<" ";
                found=1;
            }
        }
        if(!found){
            cout<<"Not found!";
        }
        cout<<endl;
    }
	else{
        cout<<"Invalid choice!"<<endl;
    }
    return 0;
}

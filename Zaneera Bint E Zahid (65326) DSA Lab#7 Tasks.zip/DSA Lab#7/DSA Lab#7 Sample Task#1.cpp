#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

Node* top = NULL;

void push(int data) {
    Node* n = new Node();
    n->data = data;
    n->next = top;
    top = n;
    cout << data << " pushed into stack." << endl;
}

void pop() {
    if (top == NULL) {
        cout << "Stack Underflow! Cannot pop." << endl;
        return;
    }
    Node* temp = top;
    cout << top->data << " popped from stack." << endl;
    top = top->next;
    delete temp;
}

// Display all stack elements
void display() {
    if (top == NULL) {
        cout << "Stack is empty!" << endl;
        return;
    }
    Node* temp = top;
    cout << "Stack elements: ";
    while (temp != NULL) {
        cout << temp->data << " -> ";
        temp = temp->next;
    }
    cout << "NULL\n";
}

int main() {
    int n, data;

    cout << "Enter number of elements to push: ";
    cin >> n;

    for (int i = 1; i <= n; i++) {
        cout << "Enter value " << i << ": ";
        cin >> data;
        push(data);
    }

    cout << "\nCurrent stack: ";
    display();

    cout << "\nPerforming one pop operation...\n";
    pop();

    cout << "Stack after pop: ";
    display();

    return 0;
}

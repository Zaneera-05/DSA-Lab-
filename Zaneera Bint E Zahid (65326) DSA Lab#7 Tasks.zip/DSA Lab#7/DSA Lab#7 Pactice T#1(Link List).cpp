#include <iostream>
#include <string>
using namespace std;
class Node {
public:
    string title;
    float price;
    int edition;
    int pages;
    Node* next;
    Node(string t, float p, int e, int pg) {
        title = t;
        price = p;
        edition = e;
        pages = pg;
        next = NULL;
    }
};
class BookStack {
private:
    Node* top;
public:
    BookStack() {
        top = NULL;
    }
    void push(string title, float price, int edition, int pages) {
        Node* newNode = new Node(title, price, edition, pages);
        newNode->next = top;
        top = newNode;
        cout << "Book \"" << title << "\" pushed onto stack.\n";
    }
    void pop() {
        if (top == NULL) {
            cout << "Stack is empty. Cannot pop.\n";
            return;
        }
        Node* temp = top;
        cout << "Book \"" << temp->title << "\" popped from stack.\n";
        top = top->next;
        delete temp;
    }
    void peek() {
        if (top == NULL) {
            cout << "Stack is empty.\n";
            return;
        }
        cout << "\nTop Book Details:\n";
        cout << "Title: " << top->title << endl;
        cout << "Price: " << top->price << endl;
        cout << "Edition: " << top->edition << endl;
        cout << "Pages: " << top->pages << endl;
    }
    void display() {
        if (top == NULL) {
            cout << "Stack is empty.\n";
            return;
        }
        cout << "\nRemaining Books in Stack:\n";
        Node* temp = top;
        while (temp != NULL) {
            cout << "-----------------------------\n";
            cout << "Title: " << temp->title << endl;
            cout << "Price: " << temp->price << endl;
            cout << "Edition: " << temp->edition << endl;
            cout << "Pages: " << temp->pages << endl;
            temp = temp->next;
        }
        cout << "-----------------------------\n";
    }
};
int main() {
    BookStack stack;
    stack.push("English", 899.50, 3, 208);
    stack.push("Physics", 1599.99, 2, 464);
    stack.push("Chemistry", 2999.00, 5, 976);
    stack.push("OOP (Java)", 799.00, 4, 336);
    stack.push("Expository Writing", 999.00, 1, 320);
    stack.peek();
    cout << "\nPopping two books...\n";
    stack.pop();
    stack.pop();
    stack.display();
    return 0;
}

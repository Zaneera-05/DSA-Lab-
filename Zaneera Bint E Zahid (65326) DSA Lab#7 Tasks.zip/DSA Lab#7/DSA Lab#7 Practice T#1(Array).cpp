#include <iostream>
#include <string>
using namespace std;
class Book {
public:
    string title;
    float price;
    int edition;
    int pages;
    Book(string t = "", float p = 0, int e = 0, int pg = 0) {
        title = t;
        price = p;
        edition = e;
        pages = pg;
    }
};
class BookStack {
private:
    static const int MAX = 10; 
    Book books[MAX];
    int top;
public:
    BookStack() {
        top = -1;
    }
    void push(string title, float price, int edition, int pages) {
        if (top == MAX - 1) {
            cout << "Stack overflow! Cannot push more books"<<" "<<endl;
            return;
        }
        top++;
        books[top] = Book(title, price, edition, pages);
        cout << "Book " << title << " pushed onto stack"<<" "<<endl;
    }
    void pop() {
        if (top == -1) {
            cout << "Stack is empty. Cannot pop"<<" "<<endl;
            return;
        }
        cout << "Book " << books[top].title << " popped from stack"<<" "<<endl;
        top--;
    }
    void peek() {
        if (top == -1) {
            cout << "Stack is empty"<<" "<<endl;
            return;
        }
        cout << "Top Book Details"<<" "<<endl;
        cout << "Title: " << books[top].title << endl;
        cout << "Price: " << books[top].price << endl;
        cout << "Edition: " << books[top].edition << endl;
        cout << "Pages: " << books[top].pages << endl;
    }
    void display() {
        if (top == -1) {
            cout << "Stack is empty"<<" "<<endl;
            return;
        }
        cout << "Remaining Books in Stack"<<" "<<endl;
        for (int i = top; i >= 0; i--) {
            cout << "-----------------------------"<<" "<<endl;
            cout << "Title: " << books[i].title << endl;
            cout << "Price: " << books[i].price << endl;
            cout << "Edition: " << books[i].edition << endl;
            cout << "Pages: " << books[i].pages << endl;
        }
        cout << "-----------------------------"<<" "<<endl;
    }
};
int main() {
    BookStack stack;
    stack.push("English", 899.50, 3, 208);
    stack.push("Physics", 1599.99, 2, 464);
    stack.push("Chemistry", 2999.00, 5, 976);
    stack.push("OOP (Java)", 799.00, 4, 336);
    stack.push("Expository Writing", 999.00, 1, 320);
    stack.peek();
    cout << "Popping two books..."<<" "<<endl;
    stack.pop();
    stack.pop();
    stack.display();
    return 0;
}

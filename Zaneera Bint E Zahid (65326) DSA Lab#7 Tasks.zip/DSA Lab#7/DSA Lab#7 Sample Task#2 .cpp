#include <iostream>
using namespace std;

#define MAX 1000
struct Stack {
    int a[MAX];  
    int top;     
};

Stack s;  
void initialize() {
    s.top = -1;
}
void push(int x) {
    if (s.top >= MAX - 1) {
        cout << "Stack Overflow!" << endl;
        return;
    }
    s.a[++s.top] = x;
    cout << x << " pushed into stack." << endl;
}
void pop() {
    if (s.top < 0) {
        cout << "Stack Underflow!" << endl;
        return;
    }
    int popped = s.a[s.top--];
    cout << popped << " popped from stack." << endl;
}
void peek() {
    if (s.top < 0) {
        cout << "Stack is empty!" << endl;
        return;
    }
    cout << "Top element is: " << s.a[s.top] << endl;
}

bool isEmpty() {
    return (s.top < 0);
}

void display() {
    if (isEmpty()) {
        cout << "Stack is empty!" << endl;
        return;
    }
    cout << "Elements present in stack: ";
    for (int i = s.top; i >= 0; i--) {
        cout << s.a[i] << " ";
    }
    cout << endl;
}

int main() {
    initialize();

    push(10);
    push(20);
    push(30);
    pop();
    peek();
    display();
    return 0;
}

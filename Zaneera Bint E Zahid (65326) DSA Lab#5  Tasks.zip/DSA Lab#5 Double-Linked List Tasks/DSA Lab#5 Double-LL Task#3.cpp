#include <iostream>
#include <string>
using namespace std;

struct Player {
    string name;
    int score;
    Player* prev;
    Player* next;
};

Player* head = NULL;

// Function to create a new player node
Player* createPlayer(string name, int score) {
    Player* newPlayer = new Player();
    newPlayer->name = name;
    newPlayer->score = score;
    newPlayer->prev = NULL;
    newPlayer->next = NULL;
    return newPlayer;
}

// Insert player in sorted order (ascending score)
void addPlayer(string name, int score) {
    Player* newPlayer = createPlayer(name, score);

    if (head == NULL) {
        head = newPlayer;
        return;
    }

    Player* temp = head;

    // insert before head (lowest score first)
    if (score < head->score) {
        newPlayer->next = head;
        head->prev = newPlayer;
        head = newPlayer;
        return;
    }

    // find correct position
    while (temp->next != NULL && temp->next->score <= score) {
        temp = temp->next;
    }

    newPlayer->next = temp->next;
    if (temp->next != NULL) {
        temp->next->prev = newPlayer;
    }
    newPlayer->prev = temp;
    temp->next = newPlayer;
}

// Delete a player by name
void deletePlayer(string name) {
    if (head == NULL) {
        cout << "No players in the list.\n";
        return;
    }

    Player* temp = head;
    while (temp != NULL && temp->name != name) {
        temp = temp->next;
    }

    if (temp == NULL) {
        cout << "Player not found.\n";
        return;
    }

    if (temp->prev != NULL) {
        temp->prev->next = temp->next;
    } else {
        head = temp->next; // deleting head
    }

    if (temp->next != NULL) {
        temp->next->prev = temp->prev;
    }

    delete temp;
    cout << "Player " << name << " deleted.\n";
}

// Display all players
void displayAll() {
    if (head == NULL) {
        cout << "No players available.\n";
        return;
    }
    Player* temp = head;
    cout << "Players List:\n";
    while (temp != NULL) {
        cout << temp->name << " - " << temp->score << "\n";
        temp = temp->next;
    }
}

// Display players in descending order
void displayDescending() {
    if (head == NULL) {
        cout << "No players available.\n";
        return;
    }

    Player* temp = head;
    while (temp->next != NULL) {
        temp = temp->next;
    }

    cout << "Players in Descending Order:\n";
    while (temp != NULL) {
        cout << temp->name << " - " << temp->score << "\n";
        temp = temp->prev;
    }
}

// Display player with lowest score
void displayLowestScore() {
    if (head == NULL) {
        cout << "No players available.\n";
        return;
    }
    cout << "Lowest Score: " << head->name << " - " << head->score << "\n";
}

// Display all players with same score
void displaySameScore(int score) {
    bool found = false;
    Player* temp = head;
    cout << "Players with score " << score << ":\n";
    while (temp != NULL) {
        if (temp->score == score) {
            cout << temp->name << " - " << temp->score << "\n";
            found = true;
        }
        temp = temp->next;
    }
    if (!found) cout << "No players found with score " << score << ".\n";
}

// Display backward from a player (all behind)
void displayBackwardFrom(string name) {
    Player* temp = head;
    while (temp != NULL && temp->name != name) {
        temp = temp->next;
    }

    if (temp == NULL) {
        cout << "Player not found.\n";
        return;
    }

    cout << "Backward from " << name << ":\n";
    while (temp != NULL) {
        cout << temp->name << " - " << temp->score << "\n";
        temp = temp->prev;
    }
}

int main() {
    int choice;
    string name;
    int score;

    do {
        cout << "\n--- Golf Tournament Menu ---\n";
        cout << "1. Add Player\n";
        cout << "2. Delete Player\n";
        cout << "3. Display All Players\n";
        cout << "4. Display Descending Order\n";
        cout << "5. Display Lowest Score\n";
        cout << "6. Display Players with Same Score\n";
        cout << "7. Display Backward from Player\n";
        cout << "8. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
            case 1:
                cout << "Enter Player Name: ";
                cin >> name;
                cout << "Enter Score: ";
                cin >> score;
                addPlayer(name, score);
                break;

            case 2:
                cout << "Enter Player Name to delete: ";
                cin >> name;
                deletePlayer(name);
                break;

            case 3:
                displayAll();
                break;

            case 4:
                displayDescending();
                break;

            case 5:
                displayLowestScore();
                break;

            case 6:
                cout << "Enter score to search: ";
                cin >> score;
                displaySameScore(score);
                break;

            case 7:
                cout << "Enter Player Name: ";
                cin >> name;
                displayBackwardFrom(name);
                break;

            case 8:
                cout << "Exiting...\n";
                break;

            default:
                cout << "Invalid choice.\n";
        }

    } while (choice != 8);

    return 0;
}

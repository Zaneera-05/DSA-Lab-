#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* prev;
    Node* next;
};

Node* head = NULL;  // start of list

// Function to create a new node
Node* createNode(int value) {
    Node* newNode = new Node();
    newNode->data = value;
    newNode->prev = NULL;
    newNode->next = NULL;
    return newNode;
}

// a) Create Doubly Linked List from user input
void createList(int n) {
    Node* temp;
    for (int i = 0; i < n; i++) {
        int value;
        cout << "Enter value for node " << i + 1 << ": ";
        cin >> value;
        Node* newNode = createNode(value);

        if (head == NULL) {
            head = newNode;
            temp = head;
        } else {
            temp->next = newNode;
            newNode->prev = temp;
            temp = newNode;
        }
    }
}

// b) Insert node at beginning
void addAtBeginning(int value) {
    Node* newNode = createNode(value);
    if (head == NULL) {
        head = newNode;
    } else {
        newNode->next = head;
        head->prev = newNode;
        head = newNode;
    }
}

// c) Insert node after value 45
void addAfterValue(int value, int newValue) {
    Node* temp = head;
    while (temp != NULL) {
        if (temp->data == value) {
            Node* newNode = createNode(newValue);
            newNode->next = temp->next;
            newNode->prev = temp;
            if (temp->next != NULL) {
                temp->next->prev = newNode;
            }
            temp->next = newNode;
            return;
        }
        temp = temp->next;
    }
    cout << "Value " << value << " not found in list.\n";
}

// d) Delete node at beginning
void deleteAtBeginning() {
    if (head == NULL) {
        cout << "List is empty.\n";
        return;
    }
    Node* temp = head;
    head = head->next;
    if (head != NULL) {
        head->prev = NULL;
    }
    delete temp;
}

// e) Delete node after value 45
void deleteAfterValue(int value) {
    Node* temp = head;
    while (temp != NULL) {
        if (temp->data == value && temp->next != NULL) {
            Node* delNode = temp->next;
            temp->next = delNode->next;
            if (delNode->next != NULL) {
                delNode->next->prev = temp;
            }
            delete delNode;
            return;
        }
        temp = temp->next;
    }
    cout << "Node after value " << value << " not found.\n";
}

// Function to display list
void displayList() {
    Node* temp = head;
    cout << "Doubly Linked List: ";
    while (temp != NULL) {
        cout << temp->data << " <-> ";
        temp = temp->next;
    }
    cout << "NULL\n";
}

// Main function
int main() {
    int n;
    cout << "Enter number of nodes: ";
    cin >> n;
    createList(n);
    displayList();

    cout << "\nInsert at beginning (value 100):\n";
    addAtBeginning(100);
    displayList();

    cout << "\nInsert after 45 (value 200):\n";
    addAfterValue(45, 200);
    displayList();

    cout << "\nDelete at beginning:\n";
    deleteAtBeginning();
    displayList();

    cout << "\nDelete after 45:\n";
    deleteAfterValue(45);
    displayList();

    return 0;
}

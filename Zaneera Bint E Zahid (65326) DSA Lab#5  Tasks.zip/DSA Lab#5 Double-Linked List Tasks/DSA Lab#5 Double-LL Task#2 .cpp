#include <iostream>
using namespace std;

struct Node {
    int rainfall;
    Node* prev;
    Node* next;
};

Node* head = NULL;

// Function to create a new node
Node* createNode(int value) {
    Node* newNode = new Node();
    newNode->rainfall = value;
    newNode->prev = NULL;
    newNode->next = NULL;
    return newNode;
}

// Function to insert at end (for days 1�7)
void insertAtEnd(int value) {
    Node* newNode = createNode(value);
    if (head == NULL) {
        head = newNode;
    } else {
        Node* temp = head;
        while (temp->next != NULL) {
            temp = temp->next;
        }
        temp->next = newNode;
        newNode->prev = temp;
    }
}

// Function to calculate total rainfall
int totalRainfall() {
    int total = 0;
    Node* temp = head;
    while (temp != NULL) {
        total += temp->rainfall;
        temp = temp->next;
    }
    return total;
}

// Function to calculate average rainfall
double averageRainfall() {
    int total = totalRainfall();
    int count = 0;
    Node* temp = head;
    while (temp != NULL) {
        count++;
        temp = temp->next;
    }
    return (count == 0) ? 0 : (double)total / count;
}

// Function to find highest and lowest rainfall day
void findHighLow() {
    if (head == NULL) {
        cout << "No data available.\n";
        return;
    }

    int maxRain = head->rainfall;
    int minRain = head->rainfall;
    int maxDay = 1, minDay = 1;

    Node* temp = head->next;
    int day = 2;

    while (temp != NULL) {
        if (temp->rainfall > maxRain) {
            maxRain = temp->rainfall;
            maxDay = day;
        }
        if (temp->rainfall < minRain) {
            minRain = temp->rainfall;
            minDay = day;
        }
        temp = temp->next;
        day++;
    }

    cout << "Day with highest rainfall: Day " << maxDay << " (" << maxRain << " mm)\n";
    cout << "Day with lowest rainfall: Day " << minDay << " (" << minRain << " mm)\n";
}

// Function to get rainfall after 5th node
void rainfallAfter5th() {
    Node* temp = head;
    int count = 1;

    while (temp != NULL && count < 6) {
        temp = temp->next;
        count++;
    }

    if (temp != NULL) {
        cout << "Rainfall of the day after 5th node: " << temp->rainfall << " mm\n";
    } else {
        cout << "There is no day after 5th node.\n";
    }
}

// Function to display rainfall of all 7 days
void displayList() {
    Node* temp = head;
    int day = 1;
    cout << "Weekly Rainfall Data:\n";
    while (temp != NULL) {
        cout << "Day " << day << ": " << temp->rainfall << " mm\n";
        temp = temp->next;
        day++;
    }
}

int main() {
    cout << "Enter rainfall for 7 days (non-negative values only):\n";
    for (int i = 1; i <= 7; i++) {
        int value;
        do {
            cout << "Day " << i << ": ";
            cin >> value;
            if (value < 0) {
                cout << "Invalid! Rainfall cannot be negative. Try again.\n";
            }
        } while (value < 0);
        insertAtEnd(value);
    }

    cout << "\n";
    displayList();

    int total = totalRainfall();
    double avg = averageRainfall();

    cout << "\nTotal rainfall for the week: " << total << " mm\n";
    cout << "Average weekly rainfall: " << avg << " mm\n";

    findHighLow();
    rainfallAfter5th();

    return 0;
}

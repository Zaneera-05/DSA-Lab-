#include <iostream>
using namespace std;
struct Node {
    int data;
    Node* next;
};
int main() {
    Node* n1 = new Node();
    Node* n2 = new Node();
    Node* n3 = new Node();
    Node* n4 = new Node();
    n1->data = 10;
    n2->data = 20;
    n3->data = 30;
    n4->data = 40;
    n1->next = n2;
    n2->next = n3;
    n3->next = n4;
    n4->next = n1; 
    Node* head = n1;
    cout << "Original Circular List: ";
    Node* temp = head;
    if (head != NULL) {
        do {
            cout << temp->data << " ";
            temp = temp->next;
        } while (temp != head);
    }
    cout << endl;
    int pos = 3; 
    if (head == NULL)
        return 0;
    if (pos == 1) {
        Node* last = head;
        while (last->next != head)
            last = last->next;
        Node* del = head;
        if (head->next == head) {
            head = NULL; 
        } else {
            head = head->next;
            last->next = head;
        }
        delete del;
    } else {
        Node* current = head;
        for (int i = 1; i < pos - 1 && current->next != head; i++) {
            current = current->next;
        }
        if (current->next != head) {
            Node* del = current->next;
            current->next = del->next;
            delete del;
        }
    }
    cout << "After Deletion at Position " << pos << ": ";
    temp = head;
    if (head != NULL) {
        do {
            cout << temp->data << " ";
            temp = temp->next;
        } while (temp != head);
    } else {
        cout << "List is empty";
    }
    cout << endl;
    return 0;
}

#include <iostream>
using namespace std;
struct Node {
    int data;
    Node* next;
    Node* prev;
};
int main() {
    Node* n1 = new Node();
    Node* n2 = new Node();
    Node* n3 = new Node();
    Node* n4 = new Node();
    n1->data = 10;
    n2->data = 20;
    n3->data = 30;
    n4->data = 40;
    n1->next = n2;
    n2->prev = n1;
    n2->next = n3;
    n3->prev = n2;
    n3->next = n4;
    n4->prev = n3;
    n4->next = n1;
    n1->prev = n4;
    Node* head = n1;
    cout << "Doubly Circular Linked List: ";
    Node* temp = head;
    if (head != NULL) {
        do {
            cout << temp->data << " <-> ";
            temp = temp->next;
        } while (temp != head);
    }
    cout << "(back to head)" << endl;
    int key;
    cout << "Enter value to search: ";
    cin >> key;
    bool found = false;
    int position = 1;
    temp = head;
    if (head != NULL) {
        do {
            if (temp->data == key) {
                cout << "Value " << key << " found at position " << position << endl;
                found = true;
                break;
            }
            temp = temp->next;
            position++;
        } while (temp != head);
    }
    if (!found) {
        cout << "Value " << key << " not found in the list." << endl;
    }
    return 0;
}

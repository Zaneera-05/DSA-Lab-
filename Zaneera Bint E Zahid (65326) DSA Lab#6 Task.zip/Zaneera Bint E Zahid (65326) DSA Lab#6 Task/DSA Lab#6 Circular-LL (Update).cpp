#include <iostream>
using namespace std;
struct Node {
    int data;
    Node* next;
    Node* prev;
};
int main() {
    Node* n1 = new Node();
    Node* n2 = new Node();
    Node* n3 = new Node();
    Node* n4 = new Node();
    n1->data = 10;
    n2->data = 20;
    n3->data = 30;
    n4->data = 40;
    n1->next = n2;  n2->prev = n1;
    n2->next = n3;  n3->prev = n2;
    n3->next = n4;  n4->prev = n3;
    n4->next = n1;
    n1->prev = n4;
    Node* head = n1;
    cout << "Original Doubly Circular List: ";
    Node* temp = head;
    if (head != NULL) {
        do {
            cout << temp->data << " ";
            temp = temp->next;
        } while (temp != head);
    }
    cout << endl;
    int pos, newValue;
    cout << "Enter position to update: ";
    cin >> pos;
    cout << "Enter new value: ";
    cin >> newValue;
    Node* current = head;
    int count = 1;
    bool valid = true;
    if (head == NULL) {
        cout << "List is empty!" << endl;
        valid = false;
    } else {
        while (count < pos) {
            current = current->next;
            count++;
            if (current == head) { 
                valid = false;
                break;
            }
        }
    }
    if (valid) {
        current->data = newValue;
        cout << "Node at position " << pos << " updated successfully!" << endl;
    } else {
        cout << "Invalid position! No update performed." << endl;
    }
    cout << "Updated List: ";
    temp = head;
    if (head != NULL) {
        do {
            cout << temp->data << " ";
            temp = temp->next;
        } while (temp != head);
    }
    cout << endl;
    return 0;
}

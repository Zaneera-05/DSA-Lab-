#include <iostream>
using namespace std;

int main() {
    int size, choice, pos, value;

    cout << "Enter initial size of array: ";
    cin >> size;

    // CREATE
    int* arr = new int[size];
    cout << "Enter " << size << " elements:\n";
    for (int i = 0; i < size; i++) {
        cin >> arr[i];
    }
    do {
        cout << "MENU"<<endl;
        cout << "1. Display (Read)\n";
        cout << "2. Insert (Create)\n";
        cout << "3. Update\n";
        cout << "4. Delete\n";
        cout << "5. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        if (choice == 1) {
            // READ
            cout << "Array elements: ";
            for (int i = 0; i < size; i++) {
                cout << arr[i] << " ";
            }
            cout << endl;
        }
        else if (choice == 2) {
            // INSERT
            cout << "Enter position (0-" << size << "): ";
            cin >> pos;
            cout << "Enter value: ";
            cin >> value;

            int* temp = new int[size + 1];
            for (int i = 0; i < pos; i++) temp[i] = arr[i];
            temp[pos] = value;
            for (int i = pos; i < size; i++) temp[i + 1] = arr[i];

            delete[] arr;
            arr = temp;
            size++;
        }
        else if (choice == 3) {
            // UPDATE
            cout << "Enter position (0-" << size - 1 << "): ";
            cin >> pos;
            cout << "Enter new value: ";
            cin >> value;

            if (pos >= 0 && pos < size)
                arr[pos] = value;
            else
                cout << "Invalid position!\n";
        }
        else if (choice == 4) {
            // DELETE
            cout << "Enter position (0-" << size - 1 << "): ";
            cin >> pos;

            if (pos >= 0 && pos < size) {
                int* temp = new int[size - 1];
                for (int i = 0; i < pos; i++) temp[i] = arr[i];
                for (int i = pos + 1; i < size; i++) temp[i - 1] = arr[i];

                delete[] arr;
                arr = temp;
                size--;
            } else {
                cout << "Invalid position!\n";
            }
        }
    } while (choice != 5);
    delete[] arr; 
    return 0;
}

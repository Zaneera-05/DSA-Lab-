#include<iostream>
using namespace std;
int main(){
	int rows;
	int columns;
	cout<<"Enter number of rows:"<<endl;
	cin>>rows;
	cout<<"Enter number of columns:"<<endl;
	cin>>columns;
	int arr[rows][columns];
	cout<<"Enter the elements of array"<<endl;
	for(int i=0;i<rows;i++){
		for(int j=0;j<columns;j++){
			cout<<"Enter element at ["<<i<<"]["<<j<<"]:";
			cin>>arr[i][j];
		}
	}
	int max=arr[0][0];
	int min=arr[0][0];
	for(int i=0;i<rows;i++){
		for(int j=0;j<columns;j++){
			if(arr[i][j]>max){
				max=arr[i][j];
			}
			if(arr[i][j]<min){
				min=arr[i][j];
			}
		}
	}
	cout<<"The array is:"<<endl;
	for(int i=0;i<rows;i++){
		for(int j=0;j<columns;j++){
			cout<<arr[i][j]<<" ";
		}
		cout<<endl;
	}
	cout<<"Maximum Value:"<<max<<endl;
	cout<<"Minimum Value:"<<min<<endl;
	return 0;
}

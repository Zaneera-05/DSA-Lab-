#include<iostream>
using namespace std;
int main(){
	int rows;
	int columns;
	cout<<"Enter number of rows:"<<endl;
	cin>>rows;
	cout<<"Enter number of columns:"<<endl;
	cin>>columns;
	int arr[rows][columns];
	cout<<"Enter the elements of array"<<endl;
	for(int i=0;i<rows;i++){
		for(int j=0;j<columns;j++){
			cout<<"Enter element at ["<<i<<"]["<<j<<"]:";
			cin>>arr[i][j];
		}
	}
	cout<<"The Array is:"<<endl;
	for(int i=0;i<rows;i++){
		for(int j=0;j<columns;j++){
			cout<<arr[i][j]<<" ";
		}
		cout<<endl;
	}
	return 0;
}

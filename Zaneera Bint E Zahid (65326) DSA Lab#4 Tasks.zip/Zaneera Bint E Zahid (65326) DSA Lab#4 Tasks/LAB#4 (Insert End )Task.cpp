#include <iostream>
using namespace std;
struct Node {
    int data;
    Node* next;
};
int main() {
    Node* n1 = new Node();
    Node* n2 = new Node();
    Node* n3 = new Node();
    Node* n4 = new Node();
    n1->data = 10;
    n2->data = 20;
    n3->data = 30;
    n4->data = 40;
    n1->next = n2;
    n2->next = n3;
    n3->next = n4;
    n4->next = NULL;
    Node* head = n1;
    // Insertng new node at end
    Node* nayaNode = new Node();
    nayaNode->data = 50;
    nayaNode->next = NULL;
    
    while (head->next != NULL) {   // going to last node..
        head = head->next;
    }
    head->next = nayaNode;          // linking our last node to new node
    head= n1;   //head back to behgining
    while (head != NULL) {
        cout << head->data << " ";
        head = head->next;
    }
    return 0;
}

#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

int main() {
    Node* n1 = new Node();
    Node* n2 = new Node();
    Node* n3 = new Node();
    n1->data = 10;
    n2->data = 20;
    n3->data = 30;
    n1->next = n2;
    n2->next = n3;
    n3->next = NULL;
    Node* head = n1;
    cout << "Original List: ";
    Node* temp = head;
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;

    // ---------- Deletion at End ----------
    if (head != NULL) {
        if (head->next == NULL) { // only one node
            delete head;
            head = NULL;
        } else {
            Node* current = head;
            while (current->next->next != NULL) { // go to 2nd last
                current = current->next;
            }
            delete current->next;   // delete last node
            current->next = NULL;
        }
    }

    cout << "After Deletion at End: ";
    temp = head;
    while (temp != NULL) {
        cout << temp->data << " ";
        temp = temp->next;
    }
    cout << endl;

    return 0;
}

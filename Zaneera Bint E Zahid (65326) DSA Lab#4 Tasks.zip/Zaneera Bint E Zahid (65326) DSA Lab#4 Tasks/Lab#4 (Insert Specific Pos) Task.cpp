#include <iostream>
using namespace std;

struct Node {
    int data;
    Node *next;
};

int main() {
    // Create initial nodes
    Node *n1 = new Node();
    Node *n2 = new Node();
    Node *n3 = new Node();

    n1->data = 10;
    n2->data = 20;
    n3->data = 30;

    n1->next = n2;
    n2->next = n3;
    n3->next = NULL;

    Node *head = n1;

    cout << "Insertion at a specific position" << endl;
    int pos, value;
    cout << "Enter the position where you want to insert new value: ";
    cin >> pos;
    cout << "Enter the value you want to insert: ";
    cin >> value;

    Node *nn = new Node();
    nn->data = value;
    nn->next = NULL;

    // Case 1: Insert at the beginning
    if (pos == 1) {
        nn->next = head;
        head = nn;
    } 
    else {
        Node *ptr = head;
        int count = 1;

        // Traverse until position-1
        while (ptr != NULL && count < pos - 1) {
            ptr = ptr->next;
            count++;
        }

        if (ptr == NULL) {
            cout << "Invalid position!" << endl;
        } else {
            nn->next = ptr->next;
            ptr->next = nn;
        }
    }

    // Final traversal
    cout << "Final traversal:" << endl;
    Node *j = head;
    while (j != NULL) {
        cout << j->data << " -> ";
        j = j->next;
    }
    cout << "NULL"<<endl;

    return 0;
}

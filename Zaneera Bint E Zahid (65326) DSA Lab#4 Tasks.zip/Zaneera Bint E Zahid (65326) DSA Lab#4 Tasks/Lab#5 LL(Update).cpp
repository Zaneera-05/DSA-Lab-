#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

int main() {
    Node* n1=new Node();
    Node* n2=new Node();
    Node* n3=new Node();
    Node* n4=new Node();

    n1->data=10;
    n2->data=20;
    n3->data=30;
    n4->data=40;

    n1->next=n2;
    n2->next=n3;
    n3->next=n4;
    n4->next=NULL;

    Node* head=n1;

    cout<<"Original List: ";
    Node* temp=head;
    while(temp!=NULL){
        cout<<temp->data<<" ";
        temp=temp->next;
    }
    cout<<endl;

    int pos, newValue;
    cout<<"Enter position to update: ";
    cin>>pos;
    cout<<"Enter new value: ";
    cin>>newValue;
    
    Node* current=head;
    for(int i=1; i<pos && current!=NULL; i++){
        current=current->next;
    }
    if(current!=NULL){
        current->data=newValue;
        cout<<"Node at position "<<pos<<" updated successfully!"<<endl;
    } 
	else 
        cout<<"Invalid position! No update performed."<<endl;
    }

    cout<<"Updated List: ";
    temp=head;
    while(temp != NULL){
        cout<<temp->data<<" ";
        temp=temp->next;
    }
    cout<<endl;
    return 0;
}

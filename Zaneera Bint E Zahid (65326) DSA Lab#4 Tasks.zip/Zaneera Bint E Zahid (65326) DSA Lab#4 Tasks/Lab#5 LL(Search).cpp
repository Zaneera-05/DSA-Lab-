#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* next;
};

int main() {
    Node* n1 = new Node();
    Node* n2 = new Node();
    Node* n3 = new Node();
    Node* n4 = new Node();
    n1->data = 10;
    n2->data = 20;
    n3->data = 30;
    n4->data = 40;
    n1->next = n2;
    n2->next = n3;
    n3->next = n4;
    n4->next = NULL;
    Node* head = n1;
    cout << "Linked List: ";
    Node* temp = head;
    while (temp != NULL) {
        cout << temp->data << "-> ";
        temp = temp->next;
    }
    cout << endl;
    int key;
    cout << "Enter value to search: ";
    cin >> key;
    int position = 1;
    bool found = false;
    temp = head;
    while (temp != NULL) {
        if (temp->data == key) {
            cout << "Value " << key << " found at position " << position << endl;
            found = true;
            break;
        }
        temp = temp->next;
        position++;
    }
    if (!found) {
        cout << "Value " << key << " not found in the list." << endl;
    }
    return 0;
}

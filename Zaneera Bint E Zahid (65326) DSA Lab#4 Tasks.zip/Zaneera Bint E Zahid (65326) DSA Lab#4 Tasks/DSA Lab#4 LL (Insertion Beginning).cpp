#include <iostream>
using namespace std;
int main(){
	struct node{
		int data;
		node *next;
	};
	node *n1=new node();
	node *n2=new node();
	node *n3=new node();
	n1->data=10;
	n2->data=20;
	n3->data=30;
	n1->next=n2;
	n2->next=n3;
	n3->next=NULL;
	node *head;
	head=n1;
		cout<<"Insertion At The Beginning"<<endl;
	node *nn1=new node();
	nn1->data=5;
	nn1->next=head;
	head=nn1;
	node *c1=head;
	while(c1!=NULL){
		cout<<c1->data<<endl;
		c1=c1->next;
	}


	return 0;
}
